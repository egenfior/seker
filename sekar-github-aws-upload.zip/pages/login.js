import { useEffect, useState } from "react";
import Head from "next/head";

const EMPTY_FORM = {
  fullName: "",
  email: "",
  phone: "",
  country: "GH",
  password: ""
};

export default function Login() {
  const [mode, setMode] = useState("create");
  const [form, setForm] = useState(EMPTY_FORM);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const saved = window.localStorage.getItem("sekarUser");
    if (saved) {
      setUser(JSON.parse(saved));
    }
  }, []);

  function updateForm(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function submit(event) {
    event.preventDefault();
    setLoading(true);
    setError("");

    try {
      const endpoint = mode === "create" ? "/api/users/register" : "/api/users/login";
      const body = mode === "create" ? form : { email: form.email, password: form.password };
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || "Account request failed");

      setUser(data.user);
      window.localStorage.setItem("sekarUser", JSON.stringify(data.user));
      setForm((current) => ({ ...current, password: "" }));
    } catch (submitError) {
      setError(submitError.message);
    } finally {
      setLoading(false);
    }
  }

  function signOut() {
    window.localStorage.removeItem("sekarUser");
    setUser(null);
  }

  return (
    <>
      <Head>
        <title>Sekar | Login</title>
        <meta name="description" content="Create or access a Sekar account." />
      </Head>

      <main className="login-shell">
        <section className="brand">
          <a href="/" className="back-link">Back to index</a>
          <h1>Sekar</h1>
          <span>Account access</span>
        </section>

        <section className="login-panel">
          {user ? (
            <div className="success-card">
              <p className="eyebrow">Signed in</p>
              <h2>{user.fullName || user.email}</h2>
              <dl>
                <div><dt>User ID</dt><dd>{user.userId}</dd></div>
                <div><dt>Email</dt><dd>{user.email || "-"}</dd></div>
                <div><dt>Phone</dt><dd>{user.phone || "-"}</dd></div>
                <div><dt>Country</dt><dd>{user.country || "-"}</dd></div>
              </dl>
              <div className="actions">
                <a href="/" className="primary">Open Sekar</a>
                <button type="button" onClick={signOut}>Sign out</button>
              </div>
            </div>
          ) : (
            <>
              <div className="tabs" aria-label="Account mode">
                <button className={mode === "create" ? "active" : ""} type="button" onClick={() => setMode("create")}>Create account</button>
                <button className={mode === "login" ? "active" : ""} type="button" onClick={() => setMode("login")}>Sign in</button>
              </div>

              <form onSubmit={submit}>
                {mode === "create" && (
                  <>
                    <label>
                      <span>Full name</span>
                      <input value={form.fullName} onChange={(e) => updateForm("fullName", e.target.value)} autoComplete="name" required />
                    </label>
                    <label>
                      <span>Phone</span>
                      <input value={form.phone} onChange={(e) => updateForm("phone", e.target.value)} autoComplete="tel" />
                    </label>
                    <label>
                      <span>Country</span>
                      <select value={form.country} onChange={(e) => updateForm("country", e.target.value)}>
                        <option value="GH">Ghana</option>
                        <option value="CI">Cote d'Ivoire</option>
                        <option value="SN">Senegal</option>
                        <option value="US">United States</option>
                      </select>
                    </label>
                  </>
                )}

                <label>
                  <span>Email</span>
                  <input type="email" value={form.email} onChange={(e) => updateForm("email", e.target.value)} autoComplete="email" required />
                </label>
                <label>
                  <span>Password</span>
                  <input type="password" value={form.password} onChange={(e) => updateForm("password", e.target.value)} autoComplete={mode === "create" ? "new-password" : "current-password"} minLength={8} required />
                </label>

                {error && <div className="error">{error}</div>}

                <button className="submit" type="submit" disabled={loading}>
                  {loading ? "Working..." : mode === "create" ? "Create account" : "Sign in"}
                </button>
              </form>
            </>
          )}
        </section>

        <style jsx>{`
          :global(*) {
            box-sizing: border-box;
          }

          :global(body) {
            margin: 0;
            background: #f5f7f8;
            color: #13201b;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          }

          .login-shell {
            align-items: center;
            display: grid;
            gap: 32px;
            grid-template-columns: minmax(0, 1fr) minmax(360px, 460px);
            margin: 0 auto;
            max-width: 1120px;
            min-height: 100vh;
            padding: 32px 18px;
          }

          .brand p,
          .eyebrow {
            color: #2d6954;
            font-size: 13px;
            font-weight: 800;
            letter-spacing: 0;
            margin: 0 0 8px;
            text-transform: uppercase;
          }

          .brand h1 {
            font-size: clamp(76px, 15vw, 160px);
            line-height: 0.9;
            margin: 0;
          }

          .brand span {
            display: block;
            font-size: 28px;
            font-weight: 800;
            margin-top: 10px;
          }

          .back-link {
            color: #13201b;
            display: inline-block;
            font-size: 14px;
            font-weight: 800;
            margin-bottom: 48px;
            text-decoration: none;
          }

          .login-panel,
          .success-card {
            background: #ffffff;
            border: 1px solid #dfe6e2;
            border-radius: 8px;
            padding: 16px;
          }

          .tabs {
            background: #eef3f0;
            border-radius: 8px;
            display: grid;
            gap: 4px;
            grid-template-columns: 1fr 1fr;
            margin-bottom: 16px;
            padding: 4px;
          }

          .tabs button,
          .submit,
          .actions button,
          .primary {
            border-radius: 8px;
            cursor: pointer;
            font: inherit;
            font-weight: 800;
            min-height: 42px;
            text-decoration: none;
          }

          .tabs button {
            background: transparent;
            border: 1px solid transparent;
            color: #46524d;
          }

          .tabs button.active {
            background: #ffffff;
            border-color: #cad5cf;
            color: #13201b;
          }

          form {
            display: grid;
            gap: 12px;
          }

          label {
            display: grid;
            gap: 6px;
          }

          label span,
          dt {
            color: #58635f;
            font-size: 12px;
            font-weight: 800;
          }

          input,
          select {
            background: #fbfcfb;
            border: 1px solid #cad5cf;
            border-radius: 8px;
            color: #13201b;
            font: inherit;
            height: 44px;
            padding: 0 10px;
            width: 100%;
          }

          .submit,
          .primary {
            align-items: center;
            background: #13201b;
            border: 1px solid #13201b;
            color: #ffffff;
            display: inline-flex;
            justify-content: center;
            margin-top: 4px;
            padding: 0 14px;
          }

          .submit:disabled {
            cursor: wait;
            opacity: 0.7;
          }

          .error {
            background: #fff5f0;
            border: 1px solid #efc6b4;
            border-radius: 8px;
            color: #7a2d14;
            padding: 12px;
          }

          .success-card h2 {
            font-size: 26px;
            margin: 0 0 14px;
          }

          dl {
            display: grid;
            gap: 10px;
            margin: 0;
          }

          dl div {
            display: grid;
            gap: 8px;
            grid-template-columns: 90px minmax(0, 1fr);
          }

          dd {
            font-weight: 800;
            margin: 0;
            overflow-wrap: anywhere;
          }

          .actions {
            display: grid;
            gap: 10px;
            grid-template-columns: 1fr 1fr;
            margin-top: 18px;
          }

          .actions button {
            background: #ffffff;
            border: 1px solid #cad5cf;
            color: #13201b;
          }

          @media (max-width: 820px) {
            .login-shell {
              align-items: start;
              grid-template-columns: 1fr;
            }

            .back-link {
              margin-bottom: 28px;
            }

            .brand h1 {
              font-size: 72px;
            }
          }
        `}</style>
      </main>
    </>
  );
}
